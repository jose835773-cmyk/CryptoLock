# CryptoLock (MVP)

Android app starter built with Kotlin + Jetpack Compose. It reads Binance Spot 24h tickers for XRP, BTC, ETH and SOL and refreshes while the app is open.

## Build APK using only your Xiaomi
1. Create/sign in to a GitHub account in Chrome.
2. Create a new public or private repository named `CryptoLock`.
3. Upload the contents of this folder (not the folder itself) to the repository, preserving `.github/workflows/build-apk.yml`.
4. Open the repository's **Actions** tab, choose **Build CryptoLock APK**, and tap **Run workflow** (or wait for the first push build).
5. Open the completed workflow run, scroll to **Artifacts**, download `CryptoLock-debug-apk`, extract it, and install `app-debug.apk`.
6. If Android asks, allow Chrome/GitHub to install unknown apps.

This is an unsigned debug APK for personal testing. Binance public market data is used without login or API keys. AIN is not included because the exact Binance Spot trading pair must be verified first.

## Current MVP limits
- The chart panel is a visual trend line placeholder, not historical candlesticks yet.
- Prices refresh every 30 seconds only while the app is open.
- Android lock-screen widgets/notifications and price alerts are not implemented in this first build.
- Xiaomi/HyperOS lock-screen widget support varies by model and OS version.
