package com.cryptolock.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.text.DecimalFormat

private val bg = Color(0xFF080D14)
private val panel = Color(0xFF111B27)
private val green = Color(0xFF19D68C)
private val red = Color(0xFFFF647C)
private val white = Color(0xFFEAF1F8)
private val muted = Color(0xFF8292A6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CryptoLockApp() }
    }
}

data class Coin(val symbol: String, val name: String, val price: Double, val change: Double)

@Composable
fun CryptoLockApp() {
    var coins by remember { mutableStateOf<List<Coin>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf("XRPUSDT") }
    var lastUpdate by remember { mutableStateOf("Conectando con Binance…") }

    suspend fun refresh() {
        try {
            val result = withContext(Dispatchers.IO) { fetchCoins() }
            coins = result
            error = if (result.isEmpty()) "No se recibieron cotizaciones." else ""
            lastUpdate = "Actualizado ahora · Binance Spot"
        } catch (e: Exception) {
            error = "No se pudo conectar. Comprueba tu conexión a Internet."
        } finally { loading = false }
    }

    LaunchedEffect(Unit) {
        while (true) { refresh(); delay(30_000) }
    }

    val active = coins.firstOrNull { it.symbol == selected } ?: coins.firstOrNull()
    Column(Modifier.fillMaxSize().background(bg).padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(26.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("CRYPTOLOCK", color = white, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text("TU MERCADO, DE UN VISTAZO", color = muted, fontSize = 10.sp, letterSpacing = 1.4.sp)
            }
            Text("● EN VIVO", color = green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(24.dp))
        Text("MERCADO", color = muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("XRPUSDT", "BTCUSDT", "ETHUSDT", "SOLUSDT").forEach { s ->
                val label = s.removeSuffix("USDT")
                Box(Modifier.background(if (selected == s) green.copy(alpha=.18f) else panel, RoundedCornerShape(10.dp)).clickable { selected = s }.padding(horizontal = 12.dp, vertical = 9.dp)) {
                    Text(label, color = if (selected == s) green else muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(18.dp)).padding(18.dp)) {
            Column {
                Text(active?.let { it.symbol.removeSuffix("USDT") + " / USDT" } ?: "XRP / USDT", color = muted, fontSize = 13.sp)
                Spacer(Modifier.height(5.dp))
                Text(active?.let { "$" + DecimalFormat("#,##0.0000").format(it.price) } ?: "—", color = white, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text(active?.let { (if (it.change >= 0) "+" else "") + DecimalFormat("0.00").format(it.change) + "% últimas 24 h" } ?: "Cargando cotización…", color = active?.let { if (it.change >= 0) green else red } ?: muted, fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))
                PriceLine(active?.change ?: 0.0)
                Spacer(Modifier.height(8.dp))
                Text("Gráfico de tendencia · variación 24 h", color = muted, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("LISTA DE SEGUIMIENTO", color = white, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
            Text("30 s", color = muted, fontSize = 10.sp)
        }
        Spacer(Modifier.height(8.dp))
        if (loading && coins.isEmpty()) CircularProgressIndicator(color = green, modifier = Modifier.size(24.dp))
        if (error.isNotEmpty()) Text(error, color = red, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(coins) { coin ->
                Row(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(12.dp)).clickable { selected = coin.symbol }.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(coin.symbol.removeSuffix("USDT"), color = white, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("USDT · Binance Spot", color = muted, fontSize = 10.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("$" + DecimalFormat("#,##0.0000").format(coin.price), color = white, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text((if (coin.change >= 0) "+" else "") + DecimalFormat("0.00").format(coin.change) + "%", color = if (coin.change >= 0) green else red, fontSize = 11.sp)
                    }
                }
            }
        }
        Text(lastUpdate, color = muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 12.dp))
    }
}

@Composable
fun PriceLine(change: Double) {
    val c = if (change >= 0) green else red
    Canvas(Modifier.fillMaxWidth().height(58.dp)) {
        val points = listOf(.82f,.74f,.79f,.61f,.68f,.48f,.55f,.36f,.42f,.25f,.31f,.18f)
        val drift = if (change >= 0) -0.12f else 0.12f
        val path = Path()
        points.forEachIndexed { i, p ->
            val x = size.width * i / (points.size - 1)
            val y = size.height * (p + drift * (i.toFloat() / (points.size - 1) - .5f)).coerceIn(.08f,.92f)
            if (i == 0) path.moveTo(x,y) else path.lineTo(x,y)
        }
        drawPath(path, c, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx()))
    }
}

private fun fetchCoins(): List<Coin> {
    val symbols = listOf("XRPUSDT", "BTCUSDT", "ETHUSDT", "SOLUSDT")
    return symbols.mapNotNull { symbol ->
        try {
            val json = JSONObject(URL("https://api.binance.com/api/v3/ticker/24hr?symbol=$symbol").readText())
            Coin(symbol, symbol.removeSuffix("USDT"), json.getString("lastPrice").toDouble(), json.getString("priceChangePercent").toDouble())
        } catch (_: Exception) { null }
    }
}
